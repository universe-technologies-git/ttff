# tftft

A Python package for tftft.

## Installation

```bash
pip install .
``` 