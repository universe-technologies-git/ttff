# ttff

A Python package for ttff.

## Installation

```bash
pip install .
```